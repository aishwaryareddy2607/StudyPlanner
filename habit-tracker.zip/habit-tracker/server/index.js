require("dotenv").config();
const express = require("express"), cors = require("cors"), mongoose = require("mongoose");
const app = express();
app.use(cors(), express.json());
app.use("/api/auth", require("./routes/auth"));
app.use("/api/habits", require("./routes/habits"));
app.use("/api", require("./routes/logs"));
app.use((err, req, res, next) => res.status(err.status || 500).json({ message: err.message || "Server error" }));
mongoose.connect(process.env.MONGO_URI || "mongodb://127.0.0.1:27017/habit-tracker")
  .then(() => app.listen(process.env.PORT || 5000, () => console.log("API running on port " + (process.env.PORT || 5000))))
  .catch(e => { console.error("MongoDB connection failed:", e.message); process.exit(1); });
