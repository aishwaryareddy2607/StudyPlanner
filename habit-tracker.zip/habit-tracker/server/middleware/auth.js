const jwt = require("jsonwebtoken");
const secret = () => process.env.JWT_SECRET || "dev_secret";
exports.sign = u => jwt.sign({ id: u._id, role: u.role }, secret(), { expiresIn: "7d" });
exports.auth = (req, res, next) => {
  const t = (req.headers.authorization || "").replace("Bearer ", "");
  try { req.user = jwt.verify(t, secret()); next(); }
  catch { res.status(401).json({ message: "Please log in again" }); }
};
exports.requireRole = role => (req, res, next) =>
  req.user.role === role ? next() : res.status(403).json({ message: "Admins only" });
