const m = require("mongoose");
const s = new m.Schema({
  habit: { type: m.Schema.Types.ObjectId, ref: "Habit", required: true },
  user: { type: m.Schema.Types.ObjectId, ref: "User", required: true },
  date: { type: String, required: true, match: /^\d{4}-\d{2}-\d{2}$/ },
  value: { type: Number, default: 0 },
  completed: { type: Boolean, default: false }
}, { timestamps: true });
s.index({ habit: 1, date: 1 }, { unique: true });
module.exports = m.model("HabitLog", s);
