const m = require("mongoose");
module.exports = m.model("Habit", new m.Schema({
  user: { type: m.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  name: { type: String, required: true, trim: true },
  description: { type: String, default: "" },
  target: { type: Number, default: 1, min: 1 },
  unit: { type: String, default: "time" },
  isActive: { type: Boolean, default: true }
}, { timestamps: true }));
