const r = require("express").Router(), Habit = require("../models/Habit"), HabitLog = require("../models/HabitLog");
const { auth } = require("../middleware/auth");
r.use(auth);
const ok = d => /^\d{4}-\d{2}-\d{2}$/.test(d || "");
// Habits for a date, each with its log (or empty log)
r.get("/logs", async (req, res) => {
  if (!ok(req.query.date)) return res.status(400).json({ message: "date must be YYYY-MM-DD" });
  const habits = await Habit.find({ user: req.user.id, isActive: true }).sort("createdAt");
  const logs = await HabitLog.find({ user: req.user.id, date: req.query.date });
  res.json(habits.map(h => ({ habit: h, log: logs.find(l => l.habit.equals(h._id)) || { value: 0, completed: false } })));
});
// Mark completed / not completed or set progress value (upsert)
r.put("/logs", async (req, res) => {
  const { habit, date, value, completed } = req.body;
  const h = await Habit.findOne({ _id: habit, user: req.user.id });
  if (!h || !ok(date)) return res.status(400).json({ message: "Valid habit and date required" });
  const v = value !== undefined ? Number(value) : completed ? h.target : 0;
  const log = await HabitLog.findOneAndUpdate({ habit, date }, { user: req.user.id, value: v, completed: completed ?? v >= h.target },
    { upsert: true, new: true, setDefaultsOnInsert: true });
  res.json(log);
});
// Daily progress
const day = async (user, date) => {
  const total = await Habit.countDocuments({ user, isActive: true });
  const done = await HabitLog.countDocuments({ user, date, completed: true });
  return { date, total, done, percent: total ? Math.round((done / total) * 100) : 0 };
};
r.get("/progress", async (req, res) => ok(req.query.date) ? res.json(await day(req.user.id, req.query.date)) : res.status(400).json({ message: "date required" }));
// Last 7 days ending at ?date
r.get("/progress/week", async (req, res) => {
  const end = new Date((req.query.date || new Date().toISOString().slice(0, 10)) + "T00:00:00Z");
  const days = [...Array(7)].map((_, i) => new Date(end - (6 - i) * 864e5).toISOString().slice(0, 10));
  res.json(await Promise.all(days.map(d => day(req.user.id, d))));
});
module.exports = r;
