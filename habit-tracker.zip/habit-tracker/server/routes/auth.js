const r = require("express").Router(), bcrypt = require("bcryptjs");
const User = require("../models/User"), { sign, auth, requireRole } = require("../middleware/auth");
const out = u => ({ token: sign(u), user: { id: u._id, name: u.name, email: u.email, role: u.role } });
r.post("/register", async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password || password.length < 6) return res.status(400).json({ message: "Name, email and a password of 6+ characters are required" });
  if (await User.findOne({ email: email.toLowerCase() })) return res.status(409).json({ message: "Email already registered" });
  const first = (await User.countDocuments()) === 0; // first account becomes admin
  const u = await User.create({ name, email, password: await bcrypt.hash(password, 10), role: first ? "admin" : "user" });
  res.status(201).json(out(u));
});
r.post("/login", async (req, res) => {
  const u = await User.findOne({ email: (req.body.email || "").toLowerCase() });
  if (!u || !(await bcrypt.compare(req.body.password || "", u.password))) return res.status(401).json({ message: "Wrong email or password" });
  res.json(out(u));
});
r.get("/users", auth, requireRole("admin"), async (req, res) => res.json(await User.find().select("-password")));
module.exports = r;
