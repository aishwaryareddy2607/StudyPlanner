const r = require("express").Router(), Habit = require("../models/Habit"), HabitLog = require("../models/HabitLog");
const { auth } = require("../middleware/auth");
r.use(auth);
const pick = b => ["name", "description", "target", "unit", "isActive"].reduce((o, k) => (b[k] !== undefined ? { ...o, [k]: b[k] } : o), {});
r.get("/", async (req, res) => res.json(await Habit.find({ user: req.user.id, isActive: true }).sort("createdAt")));
r.post("/", async (req, res) => {
  if (!req.body.name) return res.status(400).json({ message: "Habit name is required" });
  res.status(201).json(await Habit.create({ ...pick(req.body), user: req.user.id }));
});
r.put("/:id", async (req, res) => {
  const h = await Habit.findOneAndUpdate({ _id: req.params.id, user: req.user.id }, pick(req.body), { new: true });
  h ? res.json(h) : res.status(404).json({ message: "Habit not found" });
});
r.delete("/:id", async (req, res) => { // soft delete keeps past progress
  const h = await Habit.findOneAndUpdate({ _id: req.params.id, user: req.user.id }, { isActive: false });
  h ? res.json({ ok: true }) : res.status(404).json({ message: "Habit not found" });
});
module.exports = r;
