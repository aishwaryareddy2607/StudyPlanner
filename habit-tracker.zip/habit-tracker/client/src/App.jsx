import { useEffect, useState, useCallback } from "react";
import { api } from "./api.js";

const today = () => new Date().toLocaleDateString("en-CA"); // YYYY-MM-DD in local time

function Auth({ onLogin }) {
  const [mode, setMode] = useState("login"), [f, setF] = useState({ name: "", email: "", password: "" }), [err, setErr] = useState("");
  const submit = async e => {
    e.preventDefault(); setErr("");
    try { const d = await api("/auth/" + mode, "POST", f); localStorage.setItem("token", d.token); localStorage.setItem("user", JSON.stringify(d.user)); onLogin(d.user); }
    catch (x) { setErr(x.message); }
  };
  const set = k => e => setF({ ...f, [k]: e.target.value });
  return (
    <main className="auth">
      <h1>Habit Tracker</h1>
      <p className="sub">Build habits that stick, one day at a time.</p>
      <form onSubmit={submit}>
        {mode === "register" && <input placeholder="Name" value={f.name} onChange={set("name")} required />}
        <input type="email" placeholder="Email" value={f.email} onChange={set("email")} required />
        <input type="password" placeholder="Password (6+ characters)" value={f.password} onChange={set("password")} required />
        {err && <p className="err">{err}</p>}
        <button className="primary">{mode === "login" ? "Log in" : "Create account"}</button>
      </form>
      <button className="link" onClick={() => setMode(mode === "login" ? "register" : "login")}>
        {mode === "login" ? "New here? Create an account" : "Have an account? Log in"}
      </button>
    </main>
  );
}

function HabitForm({ initial, onSave, onCancel }) {
  const [f, setF] = useState(initial || { name: "", description: "", target: 1, unit: "time" });
  const set = k => e => setF({ ...f, [k]: e.target.value });
  return (
    <form className="card form" onSubmit={e => { e.preventDefault(); onSave({ ...f, target: Number(f.target) || 1 }); }}>
      <input placeholder="Habit name, e.g. Drink water" value={f.name} onChange={set("name")} required />
      <input placeholder="Description (optional)" value={f.description} onChange={set("description")} />
      <div className="row">
        <input type="number" min="1" value={f.target} onChange={set("target")} title="Daily target" />
        <input placeholder="Unit (glasses, minutes)" value={f.unit} onChange={set("unit")} />
      </div>
      <div className="row"><button className="primary">{initial ? "Save changes" : "Add habit"}</button>
        {onCancel && <button type="button" onClick={onCancel}>Cancel</button>}</div>
    </form>
  );
}

export default function App() {
  const [user, setUser] = useState(() => JSON.parse(localStorage.getItem("user") || "null"));
  const [date, setDate] = useState(today()), [items, setItems] = useState([]), [prog, setProg] = useState(null), [week, setWeek] = useState([]);
  const [adding, setAdding] = useState(false), [editing, setEditing] = useState(null), [err, setErr] = useState(""), [users, setUsers] = useState(null);

  const load = useCallback(async () => {
    try {
      const [i, p, w] = await Promise.all([api("/logs?date=" + date), api("/progress?date=" + date), api("/progress/week?date=" + date)]);
      setItems(i); setProg(p); setWeek(w); setErr("");
    } catch (e) { if (e.message.includes("log in")) logout(); else setErr(e.message); }
  }, [date]);
  useEffect(() => { if (user) load(); }, [user, load]);

  const logout = () => { localStorage.clear(); setUser(null); };
  const log = async (habit, body) => { await api("/logs", "PUT", { habit: habit._id, date, ...body }); load(); };
  const save = async h => { editing ? await api("/habits/" + editing._id, "PUT", h) : await api("/habits", "POST", h); setAdding(false); setEditing(null); load(); };
  const remove = async h => { if (confirm(`Delete "${h.name}"? Past progress is kept.`)) { await api("/habits/" + h._id, "DELETE"); load(); } };

  if (!user) return <Auth onLogin={setUser} />;
  return (
    <main className="app">
      <header>
        <div><h1>Habit Tracker</h1><p className="sub">Hi {user.name}</p></div>
        <div className="row">
          {user.role === "admin" && <button onClick={async () => setUsers(users ? null : await api("/auth/users"))}>{users ? "Hide users" : "All users"}</button>}
          <button onClick={logout}>Log out</button>
        </div>
      </header>
      {users && <section className="card"><b>Registered users ({users.length})</b>{users.map(u => <p key={u._id}>{u.name} · {u.email} · {u.role}</p>)}</section>}

      <section className="progress card">
        <div className="row between">
          <input type="date" value={date} max={today()} onChange={e => setDate(e.target.value)} />
          <button onClick={() => setDate(today())}>Today</button>
        </div>
        <div className="big">{prog ? `${prog.done} of ${prog.total} done` : "…"}<span>{prog?.percent ?? 0}%</span></div>
        <div className="bar"><i style={{ width: (prog?.percent ?? 0) + "%" }} /></div>
        <div className="week">{week.map(d => (
          <button key={d.date} className={d.date === date ? "on" : ""} onClick={() => setDate(d.date)} title={`${d.date}: ${d.percent}%`}>
            <i style={{ height: Math.max(d.percent, 6) + "%" }} /><small>{new Date(d.date + "T00:00").toLocaleDateString("en", { weekday: "short" })}</small>
          </button>))}
        </div>
      </section>

      {err && <p className="err">{err}</p>}
      {items.length === 0 && !adding && <p className="empty">No habits yet. Add your first one to start tracking.</p>}
      {items.map(({ habit: h, log: l }) => editing?._id === h._id ? <HabitForm key={h._id} initial={editing} onSave={save} onCancel={() => setEditing(null)} /> : (
        <article key={h._id} className={"card habit" + (l.completed ? " done" : "")}>
          <button className="check" aria-label={l.completed ? "Mark not completed" : "Mark completed"} onClick={() => log(h, { completed: !l.completed })}>{l.completed ? "✓" : ""}</button>
          <div className="grow"><b>{h.name}</b><small>{h.description}</small></div>
          {h.target > 1 && <label className="val"><input type="number" min="0" value={l.value} onChange={e => log(h, { value: e.target.value })} /> / {h.target} {h.unit}</label>}
          <button className="ghost" onClick={() => setEditing(h)}>Edit</button>
          <button className="ghost" onClick={() => remove(h)}>Delete</button>
        </article>))}
      {adding ? <HabitForm onSave={save} onCancel={() => setAdding(false)} /> : <button className="primary add" onClick={() => setAdding(true)}>+ Add habit</button>}
    </main>
  );
}
