# MERN Habit Tracker

Add habits, track them by date, mark completed / not completed, edit or delete them, and watch daily and weekly progress.
Stack: MongoDB + Express + React (Vite) + Node, JWT auth, role-based access (first registered user is `admin`).

## Run
Requires Node 18+ and a running MongoDB (local or Atlas).

```bash
# terminal 1 - API
cd server && cp .env.example .env && npm install && npm run dev

# terminal 2 - UI
cd client && npm install && npm run dev      # open http://localhost:5173
```

## API
| Method | Route | Purpose |
|---|---|---|
| POST | /api/auth/register, /api/auth/login | Sign up / log in (JWT) |
| GET | /api/auth/users | Admin only: list users |
| GET/POST | /api/habits | View all / add habit |
| PUT/DELETE | /api/habits/:id | Update / soft-delete habit |
| GET | /api/logs?date=YYYY-MM-DD | Habits with their status for a date |
| PUT | /api/logs | Mark completed / set progress `{habit,date,completed|value}` |
| GET | /api/progress?date= | Daily progress |
| GET | /api/progress/week?date= | Last 7 days |
